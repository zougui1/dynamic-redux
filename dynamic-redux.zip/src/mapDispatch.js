import { createMapper } from './Mappers';

export const mapDispatch = createMapper('dispatch');
