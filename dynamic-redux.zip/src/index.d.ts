declare module 'dynamic-redux';
