import { createMapper } from './Mappers';

export const mapState = createMapper('state');
