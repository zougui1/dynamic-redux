export const mappersData = {
  selectors: {}
};
