import { SET_MY_PROPERTY } from '../action-types/example';

export const setMyProperty = myProperty => ({ payload: myProperty, type: SET_MY_PROPERTY });
