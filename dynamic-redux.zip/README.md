## installation

> npm i

## build the code

> npm run build


## to do
* pass to second argument of the first function on the middlewares the current state
* pass to third argument of the first function on the middlewares the actions of the current state
